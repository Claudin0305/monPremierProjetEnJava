package ht.gestion.etudiant;

import ht.gestion.client.*;

public class Etudiant extends Client{
	
	  protected String filiere;
	  protected String niveau;

	  public Etudiant(){}

	  public  Etudiant(String id, String nom, String prenom, String statut, String tel, String filiere, String niveau, String sexe){
		  		super(id, nom, prenom, statut, tel, sexe);
		  		this.filiere = filiere;
		  		this.niveau = niveau;
	  }

	  public String getFiliere() {
	  return this.filiere;
	  }

	  public String getNiveau() {
	  return this.niveau;
	  }

	  public void setFiliere(String filiere){
		  if(filiere != null) {
			  this.filiere = filiere;
		  }
	  }

	  public void setNiveau(String niveau){
		  if(niveau != null) {
			  this.niveau = niveau;
		  }
	  }

	  public String afficherClient() {
	  return super.afficherClient() + "\t\t" + this.filiere + "\t\t" + this.niveau;
	  }

}
