package ht.gestion.menu;
import java.util.Scanner;

public class ClassMenu {
	static Scanner keyb = new Scanner(System.in);

	/***************************************************************************************************************************
	 * 							LES MENUS DU PROGRAMME
	 * *************************************************************************************************************************
	 * */
	public static char menuPrincipal() {
		
		System.out.println("================================ MENU PRINCIPAL ====================");
		System.out.println("\t\t\t1.- GESTION CLIENTS ");
		System.out.println("\t\t\t2.- GESTION VENTES");
		System.out.println("\t\t\t3.- A PROPOS DU PROGRAMME");
		System.out.println("\t\t\t0.- QUITTER LE PROGRAMME");
		System.out.print("\n\t\t Vontre choix : ");
				
		try {
		return keyb.nextLine().charAt(0);
		}catch(StringIndexOutOfBoundsException e) {
			return 'q';
		}
	}

	public static char menuGestionClient() {
		System.out.println("=======##=== Menu gestion clients ==##======");
		System.out.println("1.- Enregistrer client");
		System.out.println("2.- Modifier client");
		System.out.println("3.- Supprimer client");
		System.out.println("4.- Afficher client");
		System.out.println("5.- Retour au menu principal");
		System.out.println("0.- Quitter le programme");;
		System.out.print("Votre choix : ");
		
		try {
		return keyb.nextLine().charAt(0);
		}catch(StringIndexOutOfBoundsException e) {
			return 'q';
		}
	}
	
	
	public static char menuGestionVente() {
		System.out.println("=======##=== Menu gestion ventes ==##======");
		System.out.println("1.- Effectuer une vente");
		System.out.println("2.- Afficher vente");
		System.out.println("3.- Retour au menu principal");
		System.out.println("0.- Quitter le programme");
		System.out.print("Votre choix : ");
					
			try {
			return keyb.nextLine().charAt(0);
			}catch(StringIndexOutOfBoundsException e) {
				return 'q';
			}
	}
	
	public static char menuModificationProfesseur() {
		System.out.println("=======##=== Menu de modification professeur ==##======");
				System.out.println("1.- Nom");
				System.out.println("2.- Prenom");
				System.out.println("3.- Telephone");
				System.out.println("4.- Matire(s) enseignee(s)");
				System.out.println("5.- Sexe");
				System.out.print("Votre choix : ");
				
			try {
			return keyb.nextLine().charAt(0);
			}catch(StringIndexOutOfBoundsException e) {
				return 'q';
			}
	}
	
	public static char menuModificationPersonnelAdmin() {
		System.out.println("=======##=== Menu de modification personnel administratif ==##======");
			System.out.println("1.- Nom");
			System.out.println("2.- Prenom");
			System.out.println("3.- Telephone");
			System.out.println("4.- Post");
			System.out.println("5.- Sexe");
			System.out.print("Votre choix : ");
			
			try {
			return keyb.nextLine().charAt(0);
			}catch(StringIndexOutOfBoundsException e) {
				return 'q';
			}
		}
public static char menuModificationEtudiant() {
	System.out.println("=======##=== Menu de modification etudiant ==##======");
		System.out.println("1.- Nom");
		System.out.println("2.- Prenom");
		System.out.println("3.- Telephone");
		System.out.println("4.- Filiere");
		System.out.println("5.- Niveau");
		System.out.println("6.- Sexe");
		System.out.print("Votre choix : ");
		
			try {
			return keyb.nextLine().charAt(0);
			}catch(StringIndexOutOfBoundsException e) {
				return 'q';
			}

	}
	
	public static char statut(){
		System.out.println("Choisissez un statut");
		System.out.println("1.- Personnel administratif");
		System.out.println("2.- Professeur");
		System.out.println("3.- Etudiant");
		System.out.print("Votre choix : ");
		
			try {
			return keyb.nextLine().charAt(0);
			}catch(StringIndexOutOfBoundsException e) {
				return 'q';
			}
	}
}

/***************************************************************************************************************************************
  											FIN DES MENUS
 * *************************************************************************************************************************************/