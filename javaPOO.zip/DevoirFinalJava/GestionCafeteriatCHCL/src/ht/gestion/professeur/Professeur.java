package ht.gestion.professeur;

import ht.gestion.client.*;

public class Professeur extends Client{
	 private String matiereEns;

	  public Professeur() {
	  }

	  public Professeur(String id, String nom, String prenom, String statut, String tel, String matiereEns, String sexe) {
		  super(id, nom, prenom, statut, tel, sexe);
		  
		  this.matiereEns = matiereEns;
	  }

	  public String getMatiereEns() {
	  return this.matiereEns;
	  }

	  public void setMatiereEns(String matiereEns){
		  if(matiereEns != null) {
			  this.matiereEns = matiereEns;
		  }
		  
	  }

	  public String afficherClient() {
	  return super.afficherClient() + "\t\t" + this.matiereEns;
	  }

}
