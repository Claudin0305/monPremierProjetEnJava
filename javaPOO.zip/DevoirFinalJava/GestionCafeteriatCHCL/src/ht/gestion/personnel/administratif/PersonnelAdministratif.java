package ht.gestion.personnel.administratif;

import ht.gestion.client.*;

public class PersonnelAdministratif extends Client{
	 private String post;

	  public PersonnelAdministratif(){
	  }

	  public PersonnelAdministratif(String id, String nom, String prenom, String statut, String tel, String post, String sexe){
		  super(id, nom, prenom, statut, tel, sexe);
		  
		  this.post = post;
	  }

	  public String getPost() {
	  return this.post;
	  }

	  public void setPost(String post){
		  if(post != null) {
			  this.post = post;
		  }
	  }

	  public String afficherClient() {
	  return super.afficherClient() + "\t\t" + this.post;
	  }

}
