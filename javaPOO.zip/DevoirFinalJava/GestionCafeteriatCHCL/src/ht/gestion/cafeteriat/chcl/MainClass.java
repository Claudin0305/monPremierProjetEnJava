package ht.gestion.cafeteriat.chcl;
/**
 * Importation des packages contenant les class qui constituent le programme
 *
 */
/* ------------------------------------------------------------------------------------
 * 						Debut de l'importation
 * ------------------------------------------------------------------------------------
 */

import java.text.SimpleDateFormat;
import java.util.Date;
import ht.gestion.client.*;
import ht.gestion.etudiant.*;
import ht.gestion.personnel.administratif.*;
import ht.gestion.professeur.*;
import ht.gestion.vente.*;
import ht.gestion.menu.*;

/* ------------------------------------------------------------------------------------
 * 						Fin de l'importation
 * ------------------------------------------------------------------------------------
 */

import java.util.Scanner;
import java.util.ArrayList;

public class MainClass {

public static Scanner keyb = new Scanner(System.in);
public static ArrayList<Client> lesClients = new ArrayList<Client>();
public static ArrayList<Vente> lesVentes = new ArrayList<Vente>();

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char rep;
		
		System.out.print("\n\t\tBienvenue sur l'application de gestion de la cafétériat du CHCL \n\n \t\t\tAppuyez sur la touche \"ENTER\" pour continuer...");
		
		try {
			rep = keyb.nextLine().charAt(0);
		}catch(StringIndexOutOfBoundsException e) {
			rep = 'q';
		}
		
		if(rep == 'q') {
			System.out.println("\n\n\n");
			programPrincipal();
		}

	}
	
	
	public static void programPrincipal() {
		char menu;
		do {	
		menu = ClassMenu.menuPrincipal();
	
		
		switch(menu) {
			case '1':
				System.out.println("Gestion Clients");
				gestionClients();
				break;
			case '2':
				gestionVentes();
				break;
			case '3':
				apropos();
				break;
				
			case '0':
				System.exit(0);
				break;
				default:
			System.out.println("Faites un choix entre 0 et 3");
		}
		
	}while(menu == 'q' || menu != '1' || menu != '2' || menu != '0' || menu != '3');
		
	}
	
	/*
	 * ****************************************************************************************************
	 * 					METHODES DE TEST
	 * ****************************************************************************************************
	 */
	
	public static boolean testChampVide(String text) {
		text = text.trim();
		if(text.isEmpty() || text.equalsIgnoreCase(" ") ||  text == null || text.equalsIgnoreCase("  ")){
			System.out.println("\nERROR !! Ce champs ne doit pas etre vide\n");
			
			return false;
			
		}
		
		return true;
	}
	
	/**
	 * Cette methode permet de verifier si un champ contient uniquement des lettres.
	 * @param text qui le champ a verifier.
	 * @return boolean
	 * */
	
	public static boolean testChiffre(String text) {
		int test = 0;
		for(int i = 0; i < text.length(); i++) {
			if(text.charAt(i) == '0' || text.charAt(i) == '1' ||text.charAt(i) == '2' ||text.charAt(i) == '3' || text.charAt(i) == '4' ||text.charAt(i) == '5'
					|| text.charAt(i) == '6' || text.charAt(i) == '7' ||text.charAt(i) == '8' || text.charAt(i) == '9') {
				test++;
			}
			if(test==1) {
				System.out.println("\nCe champ ne doit contenir que des lettres\n");
				return false;
			}
			
		}
		return true;
	}
	
	public static boolean testLong(String text) {
		if(text.length() < 3) {
			System.out.println("\nCe champ doit contenir au moins 3 caractere\n");
			return false;
		}
		
		
		return true;
	}
	
	public static boolean authentification(String tel) {
		if(!(tel.charAt(0) == '4' || tel.charAt(0) == '2' || tel.charAt(0) == '3')) {
			System.out.println("\nERROR : Le numero doit etre commence par 2, 3 ou 4\n");
			return false;
		}
		
		return true;
	}
	
	public static boolean authentificationSize(String tel) {
		if(tel.length()  != 8) {
			System.out.println("\nERROR : Le numero doit contenir 8 chiffres ! \n");
			return false;
		}
		
		return true;
	}
	
	/**
	 * Cette methode permet de verifier si un champ contient uniquement des chiffres.
	 * @param text qui le champ a verifier.
	 * @return boolean
	 * */
	
	public static boolean testLettre(String text) {
		int test = 0;
		for(int i = 0; i < text.length(); i++) {
			if(!(text.charAt(i) == '0' || text.charAt(i) == '1' ||text.charAt(i) == '2' ||text.charAt(i) == '3' || text.charAt(i) == '4' ||text.charAt(i) == '5'
					|| text.charAt(i) == '6' || text.charAt(i) == '7' ||text.charAt(i) == '8' || text.charAt(i) == '9')) {
				test++;
			}
			if(test == 1) {
				System.out.println("\nCe champ ne doit contenir que des chiffres\n");
				return false;
			}
			
		}
		return true;
	}
	
	public static boolean testSexe(String sexe) {
		if(!(sexe.equalsIgnoreCase("Masculin") || sexe.equalsIgnoreCase("Feminin"))) {
			System.out.println("ERROR ! Le sexe doit être Masculin ou Feminin ! \n");
			return false;
		}
		return true;
	}
	
	
	/***************************************************************************************************************************************
	 												LISTE DES FILIERES
	 **************************************************************************************************************************************/
	
	public static boolean niveau(String filiere, String niveau) {
		
		if(!(niveau.equalsIgnoreCase("EUF") || niveau.equalsIgnoreCase("L1") || niveau.equalsIgnoreCase("L2") || niveau.equalsIgnoreCase("L3")||
				niveau.equalsIgnoreCase("L4") || niveau.equalsIgnoreCase("L5") || niveau.equalsIgnoreCase("L6"))) {
			System.out.println("\n\t\tCe niveau n'existe pas. ");
			System.out.println("==================================================================================================================");
			System.out.println("\t\t\tVoici la liste des niveaux : ");
			System.out.println("\t\t\tEUF - L1 - L2 - L3 - L4 - L5 - L6");
			return false;
		}
		
		if(testFiliere(filiere)) {
			if(filiere.equalsIgnoreCase("Sciences Informatiques") || filiere.equalsIgnoreCase("sociologie") || filiere.equalsIgnoreCase("sciences politiques")
					|| filiere.equalsIgnoreCase("travail social") || filiere.equalsIgnoreCase("psychologie") || filiere.equalsIgnoreCase("education")
					|| filiere.equalsIgnoreCase("Beaux arts") || filiere.equalsIgnoreCase("Environnement") || filiere.equalsIgnoreCase("Amenagement")) {
				if(!(niveau.equalsIgnoreCase("EUF") || niveau.equalsIgnoreCase("L1") || niveau.equalsIgnoreCase("L2") || niveau.equalsIgnoreCase("L3"))) {
					System.out.println("\t\tERROR ! Pour cette filière, les niveaux sont : EUF - L1 - L2 - L3\n");
					return false;
				}else {
					return true;
				}
			}else if(filiere.equalsIgnoreCase("Genie") || filiere.equalsIgnoreCase("Agronomie")) {
				if(!(niveau.equalsIgnoreCase("EUF") || niveau.equalsIgnoreCase("L1") || niveau.equalsIgnoreCase("L2") || niveau.equalsIgnoreCase("L3")
						|| niveau.equalsIgnoreCase("L4"))) {
					System.out.println("\t\tERROR ! Pour cette filière, les niveaux sont : EUF - L1 - L2 - L3 - L4");
					return false;
					
				}else {
					return true;
				}
				
			}else {
				if(!(niveau.equalsIgnoreCase("EUF") || niveau.equalsIgnoreCase("L1") || niveau.equalsIgnoreCase("L2") || niveau.equalsIgnoreCase("L3")
						|| niveau.equalsIgnoreCase("L4") || niveau.equalsIgnoreCase("L5") || niveau.equalsIgnoreCase("L6"))) {
					System.out.println("\t\tERROR ! Pour cette filière, les niveaux sont : EUF - L1 - L2 - L3 - L4 - L5 - L6");
					return false;
					
				}else {
					return true;
				}
			}
		}
		
		return true;
	}
	
	public static boolean testFiliere(String filiere) {
		if(!(filiere.equalsIgnoreCase("Sciences informatiques") || filiere.equalsIgnoreCase("Genie") || filiere.equalsIgnoreCase("Agronomie") ||
				filiere.equalsIgnoreCase("Environnement") || filiere.equalsIgnoreCase("Amenagement") || filiere.equalsIgnoreCase("Medecine") || 
				filiere.equalsIgnoreCase("Beaux Arts") || filiere.equalsIgnoreCase("Sociologie") || filiere.equalsIgnoreCase("Psychologie") || 
				filiere.equalsIgnoreCase("Sciences Politiques") || filiere.equalsIgnoreCase("Travail Social") || filiere.equalsIgnoreCase("Education"))) {
			
			System.out.println(filiere + " : Cette filiere n'existe pas ! \n");
			System.out.println("==================================================================================================================");
			System.out.println("\t\t\t\tVoici la liste des filieres");
			System.out.println("\t\t Sciences informatiques - Genie - Agronomie - Environnement - Amenagement - Medecine");
			System.out.println("\t\tBeaux Arts - Sociologie - Psychologie - Sciences Politiques - Travail Social - Education");
			
			return false;
		}
		
		return true;
	}
	
	public static boolean existe(String tel) {
		int i, pos = -1;
		for(i = 0; i < lesClients.size(); i++) {
			if(lesClients.get(i).getTel().equalsIgnoreCase(tel)) {
				pos = i;
			}
		}
		
		if(pos != -1) {
			System.out.println("\t\tUn autre client a deja ce numero !! ");
			return false;
		}
		
		
		return true;
	}
	public static void header() {
		System.out.println("\nID \t\tNOM \t\tPrenom \t\tSEXE \t\t\tSTATUT \t\tTELEPHONE \t\tFiliere/Post/Matiere(s) \t\tNIVEAU\n");
	}
	
	public static void separateur() {
		System.out.println("_______________________________________________________________________________________________________________________________________________________________");
	}
	
	public static void replay(char answer) {
		if(answer == 'n' || answer == 'N') {
			char R;
		do {	
			System.out.print("\nVoulez vous modifier un autre client? O = Oui, N = Non : ");
			try {
				R = keyb.nextLine().charAt(0);
			}catch(StringIndexOutOfBoundsException e) {
				R = 'q';
			}
		}while(R == 'q' && R != 'N' && R != 'n' && R != 'O' && R != 'o');
		
		if(R == 'O' || R == 'o') {
			modifierClient();
		}else {
			retour();
		}
	}
	}
	 
	/***************************************************************************************************************************************
	 * 											GESTION CLIENTS
	 * ************************************************************************************************************************************/
	
	public static void gestionClients() {
		char menu;
	do {
		menu = ClassMenu.menuGestionClient();
		
		switch(menu) {
		case '1':
			enregistrerClient();
			break;
		case '2':
			modifierClient();
			break;
		case '3':
			supprimerClient();
			break;
		case '4':
			afficherClient();
			break;
		case '5':
			programPrincipal();
			 break;
		case '0':
			System.exit(0);
			break;
			default:
				System.out.println("\n\tFaites un choix entre 0 et 5");
			
			
		}
	}while(menu == 'q' || menu != '0' || menu != '1' || menu != '2' || menu != '3' || menu != '4' || menu != '5');
		
	}
	
	public static void enregistrerClient() {
		String nom, prenom, tel, statut, matiere, filiere, niveau, post, sexe;
		char rep;
		
do {
	String id = "";
	
		System.out.println("\n===== Enregistrement de client ======\n");
		do {
			System.out.print("Saisir le prenom du client : ");
				prenom = keyb.nextLine(); 
		}while(testChiffre(prenom) != true || testChampVide(prenom) != true || testLong(prenom) != true);
		
		do {
			System.out.print("Saisir le nom du client : ");
				nom = keyb.nextLine(); 
		}while(testChiffre(nom) != true || testChampVide(nom) != true || testLong(nom) != true);
		
		id = prenom.charAt(0) +""+ nom.charAt(0) + "-" + Client.getCompteur();
		
		do {
			System.out.print("Saisir le numero de telephone du client : ");
				tel = keyb.nextLine(); 
		}while(testLettre(tel) != true || authentification(tel) != true || authentificationSize(tel) != true || existe(tel) != true);
		
		do {
			System.out.print("Saisir le sexe du client (Masculin/Feminin) : ");
			sexe = keyb.nextLine();
		}while(testChampVide(sexe) != true || testSexe(sexe) != true);
		
		char etat = ClassMenu.statut();
		
		do {
			switch(etat) {
			case '1':
				statut = "Personnel administratif";
				
				do {
					System.out.print("Saisir le poste du client : ");
						post = keyb.nextLine(); 
				}while(testChiffre(post) != true || testChampVide(post) != true );
				
				lesClients.add(new PersonnelAdministratif(id, nom, prenom, statut, tel, post, sexe));
				
				break;
				
			case '2':
				statut = "Professeur";
				
				do {
					System.out.print("Saisir le(s) matiere(s) que le client enseigne : ");
					matiere = keyb.nextLine(); 
				}while(testChampVide(matiere) != true );
				
				lesClients.add(new Professeur(id, nom, prenom, statut, tel, matiere, sexe));
				
				break;
			case '3':
					statut = "Etudiant";
					
					  do { 
						  System.out.print("Saisir la filiere du client : ");
					   		filiere =keyb.nextLine();
					   }while(testChiffre(filiere) != true ||testChampVide(filiere) != true || testFiliere(filiere) != true);
					 
					
					do {
						System.out.print("Saisir le niveau du client : ");
							niveau = keyb.nextLine(); 
					}while(testChampVide(niveau) != true || niveau(filiere, niveau) != true);
					
					lesClients.add(new Etudiant(id, nom, prenom, statut, tel, filiere, niveau, sexe));
				break;
				default:
					System.out.println("\nFaites un choix entre 1 et 3 \n");
				
			}
			do {
				System.out.print("Voulez vous faire un autre enregistrement? O = Oui, N = Non : ");
			try {
				 rep = keyb.nextLine().charAt(0);
			}catch(StringIndexOutOfBoundsException e) {
				rep = 'q';
			}
				 
			}while(rep != 'O' && rep != 'N' && rep != 'n' && rep != 'o' || rep == 'q');
			
		}while(etat != '1' && etat != '2' && etat != '3');
	
	}while(rep =='O' || rep == 'o');

	retour();
}
	
	public static void modifierClient() {
		String nom, prenom, tel, id = "", matiere, filiere, niveau, post, sexe;
		char  rep1, answer;
				int i, pos;
if(lesClients.size() == 0) {
	System.out.println("\n\tCe module n'est pas disponible !");
	retour();
}else {
		do {
			pos = -1;
				
				System.out.println("\n===== Modification de client ======\n");
				
				do {
					System.out.print("Saisir l'identifiant du client a modifier : ");
						id = keyb.nextLine();
				}while(testChampVide(id) != true);
				
				for(i = 0; i < lesClients.size(); i++) {
					if(lesClients.get(i).getId().equalsIgnoreCase(id)) {
						pos = i;
					}
				}
				
				if(pos != -1) {
					String stat = lesClients.get(pos).getStatut();
					
					switch(stat) {
					case "Etudiant":
						char menu;
		do {	
			
					do {
						menu = ClassMenu.menuModificationEtudiant();
						
						switch(menu) {
						case '1':
							do {
								System.out.print("Saisir le nouveau nom : ");
									nom = keyb.nextLine();
							}while(testChampVide(nom) != true || testLong(nom) != true || testChiffre(nom) != true);
									lesClients.get(pos).setNom(nom);
							break;
							
						case '2':
							do {
								System.out.print("Saisir le nouveau prenom : ");
									prenom = keyb.nextLine();
							}while(testChampVide(prenom) != true || testLong(prenom) != true || testChiffre(prenom) != true);
									lesClients.get(pos).setPrenom(prenom);
							break;
							
						case '3':
							do {
								System.out.print("Saisir le nouveau numero de tel : ");
									tel = keyb.nextLine();
							}while(testLettre(tel) != true || authentification(tel) != true || authentificationSize(tel) != true || existe(tel) != true);
									lesClients.get(pos).setTel(tel);
							break;
							
							
						case '4':
							do {
								System.out.print("Saisir la nouvelle filiere  : ");
									filiere = keyb.nextLine();
							}while(testChampVide(filiere) != true ||  testChiffre(filiere) != true || testFiliere(filiere) != true);
									((Etudiant) lesClients.get(pos)).setFiliere((filiere));
							break;
							
						case '5':
							do {
								System.out.print("Saisir le niveau du client  : ");
									niveau = keyb.nextLine();
							}while(testChampVide(niveau) != true || niveau(((Etudiant) lesClients.get(pos)).getFiliere(), niveau) != true);
									((Etudiant) lesClients.get(pos)).setNiveau((niveau));
							break;
						case '6':
							do {
								System.out.print("Saisir le sexe du client (Masculin/Feminin) : ");
									sexe = keyb.nextLine();
							}while(testChampVide(sexe) != true || testSexe(sexe) != true);
									lesClients.get(pos).setSexe(sexe);
							break;
							
							default:
								System.out.println("\n\tFaites un choix entre 1 et 6");
						}
						do {
							System.out.print("Voulez vous faire une autre modification ? O = Oui, N = non : ");
						try {
							answer = keyb.nextLine().charAt(0);
						}catch(StringIndexOutOfBoundsException e) {
							answer = 'q';
						}
						}while(answer != 'O' && answer != 'N' && answer != 'n' && answer != 'o' || answer == 'q');
						
					}while(answer == 'O' || answer == 'o');
					
						replay(answer);
					
		}while(menu == 'q' || menu != '1' || menu != '2' || menu !='3' || menu != '4' || menu != '5'  );	
						break;
					case "Professeur":
						char men;
			do {
				men = ClassMenu.menuModificationProfesseur();
					do {
						switch(men) {
						case '1':
							do {
								System.out.print("Saisir le nouveau nom : ");
									nom = keyb.nextLine();
							}while(testChampVide(nom) != true || testLong(nom) != true || testChiffre(nom) != true);
									lesClients.get(pos).setNom(nom);
							break;
							
						case '2':
							do {
								System.out.print("Saisir le nouveau prenom : ");
									prenom = keyb.nextLine();
							}while(testChampVide(prenom) != true || testLong(prenom) != true || testChiffre(prenom) != true);
									lesClients.get(pos).setPrenom(prenom);
							break;
							
						case '3':
							do {
								System.out.print("Saisir le nouveau numero de tel : ");
									tel = keyb.nextLine();
							}while(testLettre(tel) != true || authentification(tel) != true || authentificationSize(tel) != true || existe(tel) != true);
									lesClients.get(pos).setTel(tel);
							break;
						
						case '4':
		
							do {
								System.out.print("Saisir le(s) matiere(s) que le client enseigne : ");
								matiere = keyb.nextLine(); 
							}while(testChampVide(matiere) != true );
							((Professeur) lesClients.get(pos)).setMatiereEns(matiere);
							
							break;
						case '5':
							do {
								System.out.print("Saisir le sexe du client (Masculin/Feminin) : ");
									sexe = keyb.nextLine();
							}while(testChampVide(sexe) != true || testSexe(sexe) != true);
									lesClients.get(pos).setSexe(sexe);
							break;
							default:
								System.out.println("\nFaites un choix entre 1 et 5\n\n");
						
						}

						do {
							System.out.print("Voulez vous faire une autre modification ? O = Oui, N = non : ");
						try {	
							answer = keyb.nextLine().charAt(0);
						}catch(StringIndexOutOfBoundsException e) {
							answer = 'q';
						}
						}while(answer != 'O' && answer != 'N' && answer != 'n' && answer != 'o' || answer == 'q');
						
					}while(answer == 'O' || answer == 'o');
					
					replay(answer);
	
			}while(men == 'q' ||  men != '1' || men != '2' || men != '3' || men != '4');
						break;
					case "Personnel administratif":
						char menu1;
		do {	
			 menu1 = ClassMenu.menuModificationPersonnelAdmin();
				do {		
						
						switch(menu1) {
		
						case '1':
							do {
								System.out.print("Saisir le nouveau nom : ");
									nom = keyb.nextLine();
							}while(testChampVide(nom) != true || testLong(nom) != true || testChiffre(nom) != true);
									lesClients.get(pos).setNom(nom);
							break;
							
						case '2':
							do {
								System.out.print("Saisir le nouveau prenom : ");
									prenom = keyb.nextLine();
							}while(testChampVide(prenom) != true || testLong(prenom) != true || testChiffre(prenom) != true);
									lesClients.get(pos).setPrenom(prenom);
							break;
							
						case '3':
							do {
								System.out.print("Saisir le nouveau numero de tel : ");
									tel = keyb.nextLine();
							}while(testLettre(tel) != true || authentification(tel) != true || authentificationSize(tel) != true || existe(tel) != true);
									lesClients.get(pos).setTel(tel);
							break;
							
						case '4':
							do {
								System.out.print("Saisir le poste du client : ");
									post = keyb.nextLine(); 
							}while(testChiffre(post) != true || testChampVide(post) != true );
							((PersonnelAdministratif) lesClients.get(pos)).setPost(post);
							break;
						case '5':
							do {
								System.out.print("Saisir le sexe du client (Masculin/Feminin) : ");
									sexe = keyb.nextLine();
							}while(testChampVide(sexe) != true || testSexe(sexe) != true);
									lesClients.get(pos).setSexe(sexe);
							break;
							default:
								System.out.println("\nFaites un choix entre 1 et 5\n\n");
						
						}

						do {
							System.out.print("Voulez vous faire une autre modification ? O = Oui, N = non : ");
						try {
							answer = keyb.nextLine().charAt(0);
						}catch(StringIndexOutOfBoundsException e) {
							answer = 'q';
						}
						}while(answer != 'O' && answer != 'N' && answer != 'n' && answer != 'o' || answer == 'q');
						
					}while(answer == 'O' || answer == 'o');
					
					replay(answer);
				
		}while(menu1 == 'q' || menu1 != '1'|| menu1 != '2'|| menu1 != '3'|| menu1 != '4');
						break;
						
						default:
							System.out.println();
					}
				}else {
					System.out.println("\n\t\tCe numero d'identifiant n'existe pas");
				}
				
				do {
					System.out.print("\t\tVoulez vous Modifier un autre client? O = Oui, N = Non : ");
				try {	
					rep1 = keyb.nextLine().charAt(0);
				}catch(StringIndexOutOfBoundsException e) {
					rep1 = 'q';
				}
				}while(rep1 != 'n' && rep1 != 'N' && rep1 != 'O' && rep1 != 'o' || rep1 == 'q');
				
		}while(rep1 == 'O' || rep1  == 'o');
		
		
	}
}
			
	public static void supprimerClient() {
		String id;
		char rep, rep1;
		int i, pos;
		if(lesClients.size() == 0) {
			System.out.println("\t\tCe module n'est pas disponible ! \n");
			retour();
		}else {
				do {
					pos = -1;
					
					System.out.println("\n===== Suppression  de client ======\n");
					
					do {
						System.out.print("Saisir l'identifiant du client a supprimer : ");
							id = keyb.nextLine();
					}while(testChampVide(id) != true);
					
					for(i = 0; i < lesClients.size(); i++) {
						if(lesClients.get(i).getId().equalsIgnoreCase(id)) {
							pos = i;
						}
					}
					
					if(pos != -1) {
						System.out.println("Voulez vous vraiment supprimer ce client?\n");
									header();
									separateur();
									System.out.println(lesClients.get(pos).afficherClient());
									separateur();
							do {		
								System.out.print("Votre choix: N = Non, O = Oui : ");
								try {
									rep = keyb.nextLine().charAt(0);
								}catch(StringIndexOutOfBoundsException e) {
									rep = 'q';
								}
							}while(rep != 'n' && rep != 'N' && rep != 'O' && rep != 'o' || rep == 'q');
							
							if(rep == 'O' || rep == 'o') {
								lesClients.remove(pos);
								System.out.println("\t\tSuppression effectuee avec succes\n\n");
										retour();
							}else {
								System.out.println("\t\tSuppression annulee !!!\n\n");
									retour();
							}
					}else {
						System.out.println("\t\tCe client n'existe pas !\n\n");
							
					}
					do {
						System.out.print("\t\tVoulez vous faire une autre suppression? O = Oui, N = Non : ");
					try {
						rep1 = keyb.nextLine().charAt(0);
					}catch(StringIndexOutOfBoundsException e) {
						rep1 = 'q';
					}
					}while(rep1 != 'n' && rep1 != 'N' && rep1 != 'O' && rep1 != 'o' || rep1 == 'q');
					
							
				}while(rep1 == 'O' || rep1  == 'o');
	}	
}
	
	public static void afficherClient() {
		if(lesClients.size()>0) {

			System.out.println("\t\t======================Voici la liste des client enregistrer=======================");
									header();
									separateur();
			for(Client client: lesClients) {
				System.out.println(client.afficherClient());
						separateur();
			}
			
			retour();
		}else {
			System.out.println("\nCe module est indisponible !\n\n");
			retour();
		}
		
	}
	

	 
	/***************************************************************************************************************************************
	 * 											GESTION VENTES
	 * ************************************************************************************************************************************/
	
	public static void gestionVentes(){
		char menuVente;
		do {
			menuVente = ClassMenu.menuGestionVente();
			switch(menuVente) {
			case '1':
				effectuerVente();
				break;
			case '2':
				afficherVente();
				break;
			case '3':
				programPrincipal();
				break;
			case '0':
				System.exit(0);
				break;
				default:
					System.out.println("\n\tFaites un choix entre 0 et 3");
					
			}
			
		}while(menuVente == 'q' || menuVente != '0'|| menuVente != '1'|| menuVente != '2'|| menuVente != '3');
	}
	
	public static void effectuerVente(){

        Date toDay = new Date();

        SimpleDateFormat formater = new SimpleDateFormat("dd−MM−yyyy");
        String date = formater.format(toDay);

		String  idClient, id, statut;
		char rep;
		int pos, pos1;
do {		
		pos = -1;
		pos1 =  -1;
		
		System.out.println("====================================Realisation d'une vente================================\n");
		if(lesClients.size() == 0) {
			System.out.println("\tCe module n'est pas disponible !\n");
			retourVente();
		}else {

			id = "vent-" + Vente.getCompteur();
			do {
				System.out.print("\tSaisir le numero du client : ");
				idClient = keyb.nextLine();
			}while(testChampVide(idClient) != true);
			
			for(int i = 0; i < lesClients.size(); i++) {
				if(lesClients.get(i).getId().equalsIgnoreCase(idClient)) {
					pos = i;
				}
			}
			
			if(pos != -1) {
				statut = lesClients.get(pos).getStatut();
				
				for(int j = 0; j < lesVentes.size(); j++) {
					if(lesVentes.get(j).getIdClient().equalsIgnoreCase(idClient)) {
						pos1 = j;
					}
				}

				if(pos1 == -1) {
					switch(statut) {
					case "Etudiant":
						lesVentes.add(new Vente(id, idClient, date, 20.0));
						break;
					case "Professeur":
						lesVentes.add(new Vente(id, idClient, date, 50.0));
						break;
					case "Personnel administratif":
						lesVentes.add(new Vente(id, idClient, date, 30.0));
						break;
					}
				}else {
					if(lesVentes.get(pos1).getDateVente().equalsIgnoreCase(date)) {
						System.out.println("\tVous ne pouvez acheter aujourd'hui. Revenez dans 24 heures !");
						retourVente();
					}else {
						switch(statut) {
						case "Etudiant":
							lesVentes.add(new Vente(id, idClient, date, 20.0));
							break;
						case "Professeur":
							lesVentes.add(new Vente(id, idClient, date, 50.0));
							break;
						case "Personnel administratif":
							lesVentes.add(new Vente(id, idClient, date, 30.0));
							break;
						}
					}
				}
			}
			
		}
		
				if(pos == -1){
					System.out.println("\n\tCe numero n'existe pas dans le system !");
					char reponse;
				do {	
					System.out.print("\tVoulez vous voir la liste des clients du system? O = Oui, N = Non : ");
					try {
						reponse = keyb.nextLine().charAt(0);
					}catch(StringIndexOutOfBoundsException e) {
						reponse = 'q';
					}
				}while(reponse == 'q' || reponse != 'O' && reponse != 'o' && reponse != 'N' && reponse != 'n');	
				
				if(reponse == 'O' || reponse == 'o') {
					afficherClient();
				}else {
					retourVente();
				}
					
				}
		
		do {
				System.out.print("\tVoulez vous effecture une autre vente? O = Oui, N = Non : ");
				try {
					rep = keyb.nextLine().charAt(0);
				}catch(StringIndexOutOfBoundsException e) {
					rep = 'q';
				}
			
		}while(rep == 'q' && rep != 'O' && rep != 'o' && rep != 'N' && rep != 'n');
		
}while(rep == 'o' || rep == 'O');

	retourVente();
		
	}
	
	public static void afficherVente(){
		if(lesVentes.size() == 0) {
			System.out.println("\tCe module n'est pas disponible !");
			retourVente();
		}else {
			System.out.println("==============================Voici la liste des ventes========================================");
					headerVente();
					separateur();
			for(Vente vente : lesVentes) {
				System.out.println(vente.afficherVente());
				separateur();
			}
		}
		
		retourVente();
	}
	
	
	public static void headerVente() {
		System.out.println("ID\t\t ID CLIENT \t\t DATE \t\t MONTANT");
	}

	/***************************************************************************************************************************************
	 * 											Sous_Programme de retour
	 * *********************************************************************************************************************************** */
	
	
	public static void retour() {
		char rep;
	do {	
		System.out.println("\t\t==== Menu de retour =====");
		System.out.println("\t\t\t1.- Retour");
		System.out.println("\t\t\t2.- Retour au programme principal");
		System.out.println("\t\t\t3.- Quitter le programme");
		System.out.print("\t\tVotre choix : ");
		
		try {	
			rep = keyb.nextLine().charAt(0);
		}catch(StringIndexOutOfBoundsException e) {
			rep = 'q';
		}
		
		switch(rep) {
		case '1':
			gestionClients();
			break;
		case '2':
			programPrincipal();
			break;
		case '3':
			System.exit(0);
			break;
			default:
				System.out.println("\nFaites un choix entre 1 et 3");
		
		
		}
	}while(rep != '1' && rep != '2' || rep == 'q');
}
	
	
	public static void retourVente() {
		char rep;
	do {	
		System.out.println("\t\t==== Menu de retour =====");
		System.out.println("\t\t\t1.- Retour");
		System.out.println("\t\t\t2.- Retour au programme principal");
		System.out.println("\t\t\t3.- Quitter le programme");
		System.out.print("\t\tVotre choix : ");
	try {	
		rep = keyb.nextLine().charAt(0);
	}catch(StringIndexOutOfBoundsException e) {
		rep = 'q';
	}
		
		switch(rep) {
		case '1':
			gestionVentes();
			break;
		case '2':

			programPrincipal();
			break;
		case '3':
			System.exit(0);
			break;
			default:
				System.out.println("\nFaites un choix entre 1 et 3");
		
		
		}
	}while(rep != '1' && rep != '2' || rep == 'q');
}
	
	public static void apropos() {
		char rep;
		System.out.println("\t\tCe programme a été réalisé dans le cadre du cours \" Introduction à la programmation en Java \".");
		System.out.println("\tCe cours est présenté par le professeur Lauraty JEAN LUCIEN, responsable de la filière Informatique.");
		System.out.println("\tLe travail est réalisé par un groupe de 3 étudiants. Dont : ");
		System.out.println("\t\t\t\t1.- Claudin SAINTIL");
		System.out.println("\t\t\t\t2.- Nakisha LOUIS");
		System.out.println("\t\t\t\t3.- Wesly TOUSSAINT");
		System.out.println("\n\tNous somme des étudiants de la L2. Pour le bon fonctionnement du programme :");
		System.out.println("\t\tA.- Pas d'affichage sans enregistrement");
		System.out.println("\t\tB.- Pas de suppression sans enregistrement");
		System.out.println("\t\tC.- Pas de modification sans enregistrement");
		System.out.println("\t\tD.- Les champs doivent obligatoirement être remplis");
		System.out.println("\t\tE.- Etc....");
		
		separateur();
	do {
		System.out.println("\n\t\t\tMENU DE RETOUR");
		System.out.println("\t\t\t1.- Retour au menu principal");
		System.out.println("\t\t\t0.- Quitter le programme");
		System.out.print("\t\tVotre choix : ");
		
		try {
			rep = keyb.nextLine().charAt(0);
		}catch(StringIndexOutOfBoundsException e) {
			rep = 'q';
		}
		
		switch(rep) {
		case '1':
			programPrincipal();
			break;
		case '0':
			System.exit(0);
			break;
			default:
				System.out.println("\t\tFaites un choix entre 0 et 1 !");
		}
		
	}while(rep == 'q' || rep != '1' || rep != '0');
	}
}
