package ht.gestion.client;

public class Client {
	
	protected String nom;
	protected String prenom;
	protected String id;
	protected String statut;
	protected String tel;
	protected String sexe;
	private static int compteur = 0;
	
// Les constructeurs
	public Client(){ }

	public Client(String id, String nom, String prenom, String statut, String tel, String sexe){
		
		this.id = id;
		this.nom = nom;
		this.prenom = prenom;
		this.statut = statut;
		this.tel = tel;
		this.sexe = sexe;
		compteur++;
		
	  }
	  
	
	/*Les getters*/
	
	public String getSexe() {
		return this.sexe;
	}
	  
	  public String getId(){
		  
	  return this.id;
	  }

	  public String getNom(){
	  return this.nom;
	  }

	  public String getPrenom(){
	  return this.prenom;
	  }

	  public String getStatut(){
	  return this.statut;
	  }
	  
	  public String getTel(){
	  return this.tel;
	  }
	  
	  public static int getCompteur() {
		  return compteur;
	  }
	  
	
	  
	  //	  Les Setters

	  public void setNom(String nom){
		  if(nom != null) {
			  this.nom = nom;
		  }
	  }

	  public void setPrenom(String prenom){
		  if(prenom != null) {
			  this.prenom = prenom;
		  }
	  }

	  public void setStatut(String statut){
		  if(statut != null) {
			  this.statut = statut;
		  }
	  }

	  public void setTel(String tel){
		  if(tel != null) {
			  this.tel = tel;
		  }
	  }
	  
	  public void setSexe(String sexe) {
		  if(sexe != null) {
			  this.sexe = sexe;
		  }
	  }


	  public String afficherClient(){
	  return this.id + "\t\t" + this.nom + "\t\t" + this.prenom + "\t\t" + this.sexe+ "\t\t" + this.statut + "\t\t" + this.tel;
	  }

	 
}
