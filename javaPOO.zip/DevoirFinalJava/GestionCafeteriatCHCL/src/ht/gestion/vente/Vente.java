package ht.gestion.vente;

public class Vente {
	 private String id;
	 private String idClient;
	 private String dateVente;
	 private double montantVente;
	 private static int compteur = 0;

	  public Vente() {}

	  public Vente(String id, String idClient, String dateVente, double montantVente){
		  this.id = id;
		  this.idClient = idClient;
		  this.dateVente = dateVente;
		  this.montantVente = montantVente;
		  compteur++;
	  }

	  public String getId() {
	  return this.id;
	  }

	  public String getIdClient() {
	  return this.idClient;
	  }

	  public String getDateVente() {
	  return this.dateVente;
	  }

	  public double getMontantVente() {
	  return this.montantVente;
	  }
	  
	  public static int getCompteur() {
		  return compteur;
	  }

	  public void setIdClient(String idClient){
		  if(idClient != null) {
			  this.idClient = idClient;
		  }
	  }

	  public void setDateVente(String dateVente){
		  if(dateVente != null) {
			  this.dateVente = dateVente;
		  }
	  }

	  public void setMontantVente(double montantVente){
		  if(montantVente > 0) {
			  this.montantVente = montantVente;
		  }
	  }

	  public String afficherVente() {
	  return this.id + "\t\t" + this.idClient + "\t\t" + this.dateVente + "\t\t" + this.montantVente;
	  }

}
